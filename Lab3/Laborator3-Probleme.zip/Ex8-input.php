<?php
    $a=150;
    $b=23;
    $sum=$a+$b;
?>