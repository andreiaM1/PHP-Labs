<html>
    <head>
        <title>Exercitiul 5</title>
    </head>
    <body>
        <?php
        for($i=0;$i<10;$i++)
            echo $i.PHP_EOL;
        ?>
    </body>
</html>