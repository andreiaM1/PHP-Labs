<html>
    <body>
        <?php
        $eur=$_REQUEST["euro"];
        $lei=$eur*4.5;
        echo "Reprezinta $lei lei";
        ?>
    </body>
</html>