<html>
    <body>
        <?php
        $a=$_POST["a"];
        $b=$_POST["b"];
        $media=($a+$b)/2;
        print "Media artimetica este: $media";
        ?>
    </body>
</html>